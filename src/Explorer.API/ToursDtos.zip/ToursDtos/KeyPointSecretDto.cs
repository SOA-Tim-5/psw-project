﻿namespace Explorer.Tours.API.Dtos
{
    public class KeyPointSecretDto
    {
        public List<string>? Images { get; set; }
        public string Description { get; set; }
    }
}
