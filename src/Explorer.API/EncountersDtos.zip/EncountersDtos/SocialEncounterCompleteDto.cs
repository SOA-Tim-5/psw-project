﻿namespace Explorer.Encounters.API.Dtos;

public class SocialEncounterCompleteDto
{
    public int EncounterId {  get; set; }
    public long UserId { get; set; }
}
