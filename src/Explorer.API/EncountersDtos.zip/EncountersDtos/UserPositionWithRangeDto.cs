﻿namespace Explorer.Encounters.API.Dtos
{
    public class UserPositionWithRangeDto
    {
        public double Range { get; set; }
        public double Longitude { get; set; }
        public double Latitude { get; set; }
    }
}
