﻿namespace Explorer.Tours.API.Dtos;

public class EquipmentUpdateDto
{
    public int string { get; set; }
    public string Name { get; set; }
    public string? Description { get; set; }
}