﻿namespace Explorer.Tours.API.Dtos;

public class TourDurationUpdateDto
{
    public int Duration { get; set; }
    public TransportType TransportType { get; set; }
}