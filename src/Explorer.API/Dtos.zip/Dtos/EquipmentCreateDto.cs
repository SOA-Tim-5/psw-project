﻿namespace Explorer.Tours.API.Dtos;

public class EquipmentCreateDto
{
    public string Name { get; set; }
    public string? Description { get; set; }
}