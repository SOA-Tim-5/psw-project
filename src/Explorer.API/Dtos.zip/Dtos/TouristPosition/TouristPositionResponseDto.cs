﻿namespace Explorer.Tours.API.Dtos.TouristPosition;

public class TouristPositionResponseDto
{
    public double Longitude { get; set; }
    public double Latitude { get; set; }
}
